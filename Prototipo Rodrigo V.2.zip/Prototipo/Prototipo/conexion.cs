﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Prototipo
{
    class conexion
    {
        //public static MySqlConnection ObtenerConexion()
        //{
        //    MySqlConnection conectar = new MySqlConnection("server=localhost;port=3306;user id=root;password=;database=biblioteca;");
            //server=127.0.0.1
        //    conectar.Open();
        //    return conectar;

        //}
        public static MySqlConnection ObtenerConexion()
        {
            MySqlConnection conectar = new MySqlConnection("server=localhost;port=3306;uid=rodrigo;password=juarez;database=dbiblioteca;");
            //server=127.0.0.1
            conectar.Open();
            return conectar;

        }
       
    }
}
