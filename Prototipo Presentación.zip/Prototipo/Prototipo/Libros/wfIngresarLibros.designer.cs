﻿namespace Prototipo
{
    partial class wfIngresarLibros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(wfIngresarLibros));
            this.cboMateria = new System.Windows.Forms.ComboBox();
            this.cboCorriente = new System.Windows.Forms.ComboBox();
            this.cboUbic = new System.Windows.Forms.ComboBox();
            this.cboEdit = new System.Windows.Forms.ComboBox();
            this.cboAutor = new System.Windows.Forms.ComboBox();
            this.txtDispo = new System.Windows.Forms.TextBox();
            this.txtEdicion = new System.Windows.Forms.TextBox();
            this.txtFecha = new System.Windows.Forms.TextBox();
            this.txtVolumen = new System.Windows.Forms.TextBox();
            this.txtNPag = new System.Windows.Forms.TextBox();
            this.txtTitulo = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.lblMateria = new System.Windows.Forms.Label();
            this.lblUbic = new System.Windows.Forms.Label();
            this.lblCorriente = new System.Windows.Forms.Label();
            this.lblEditorial = new System.Windows.Forms.Label();
            this.lblAutor = new System.Windows.Forms.Label();
            this.lblDispo = new System.Windows.Forms.Label();
            this.lblEdicion = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblNPag = new System.Windows.Forms.Label();
            this.lblVolumen = new System.Windows.Forms.Label();
            this.lblFecha = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnIngresar = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cboMateria
            // 
            this.cboMateria.FormattingEnabled = true;
            this.cboMateria.Location = new System.Drawing.Point(478, 197);
            this.cboMateria.Margin = new System.Windows.Forms.Padding(2);
            this.cboMateria.Name = "cboMateria";
            this.cboMateria.Size = new System.Drawing.Size(100, 21);
            this.cboMateria.TabIndex = 48;
            // 
            // cboCorriente
            // 
            this.cboCorriente.FormattingEnabled = true;
            this.cboCorriente.Location = new System.Drawing.Point(262, 203);
            this.cboCorriente.Margin = new System.Windows.Forms.Padding(2);
            this.cboCorriente.Name = "cboCorriente";
            this.cboCorriente.Size = new System.Drawing.Size(100, 21);
            this.cboCorriente.TabIndex = 47;
            // 
            // cboUbic
            // 
            this.cboUbic.FormattingEnabled = true;
            this.cboUbic.Location = new System.Drawing.Point(84, 197);
            this.cboUbic.Margin = new System.Windows.Forms.Padding(2);
            this.cboUbic.Name = "cboUbic";
            this.cboUbic.Size = new System.Drawing.Size(100, 21);
            this.cboUbic.TabIndex = 46;
            // 
            // cboEdit
            // 
            this.cboEdit.FormattingEnabled = true;
            this.cboEdit.Location = new System.Drawing.Point(478, 150);
            this.cboEdit.Margin = new System.Windows.Forms.Padding(2);
            this.cboEdit.Name = "cboEdit";
            this.cboEdit.Size = new System.Drawing.Size(100, 21);
            this.cboEdit.TabIndex = 45;
            // 
            // cboAutor
            // 
            this.cboAutor.FormattingEnabled = true;
            this.cboAutor.Location = new System.Drawing.Point(262, 156);
            this.cboAutor.Margin = new System.Windows.Forms.Padding(2);
            this.cboAutor.Name = "cboAutor";
            this.cboAutor.Size = new System.Drawing.Size(100, 21);
            this.cboAutor.TabIndex = 44;
            // 
            // txtDispo
            // 
            this.txtDispo.Location = new System.Drawing.Point(84, 150);
            this.txtDispo.Margin = new System.Windows.Forms.Padding(2);
            this.txtDispo.Name = "txtDispo";
            this.txtDispo.Size = new System.Drawing.Size(100, 20);
            this.txtDispo.TabIndex = 43;
            // 
            // txtEdicion
            // 
            this.txtEdicion.Location = new System.Drawing.Point(478, 95);
            this.txtEdicion.Margin = new System.Windows.Forms.Padding(2);
            this.txtEdicion.Name = "txtEdicion";
            this.txtEdicion.Size = new System.Drawing.Size(100, 20);
            this.txtEdicion.TabIndex = 42;
            // 
            // txtFecha
            // 
            this.txtFecha.Location = new System.Drawing.Point(262, 98);
            this.txtFecha.Margin = new System.Windows.Forms.Padding(2);
            this.txtFecha.Name = "txtFecha";
            this.txtFecha.Size = new System.Drawing.Size(100, 20);
            this.txtFecha.TabIndex = 41;
            // 
            // txtVolumen
            // 
            this.txtVolumen.Location = new System.Drawing.Point(84, 91);
            this.txtVolumen.Margin = new System.Windows.Forms.Padding(2);
            this.txtVolumen.Name = "txtVolumen";
            this.txtVolumen.Size = new System.Drawing.Size(100, 20);
            this.txtVolumen.TabIndex = 40;
            // 
            // txtNPag
            // 
            this.txtNPag.Location = new System.Drawing.Point(478, 31);
            this.txtNPag.Margin = new System.Windows.Forms.Padding(2);
            this.txtNPag.Name = "txtNPag";
            this.txtNPag.Size = new System.Drawing.Size(100, 20);
            this.txtNPag.TabIndex = 39;
            // 
            // txtTitulo
            // 
            this.txtTitulo.Location = new System.Drawing.Point(262, 35);
            this.txtTitulo.Margin = new System.Windows.Forms.Padding(2);
            this.txtTitulo.Name = "txtTitulo";
            this.txtTitulo.Size = new System.Drawing.Size(100, 20);
            this.txtTitulo.TabIndex = 38;
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(84, 31);
            this.txtNombre.Margin = new System.Windows.Forms.Padding(2);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(100, 20);
            this.txtNombre.TabIndex = 37;
            // 
            // lblMateria
            // 
            this.lblMateria.AutoSize = true;
            this.lblMateria.Location = new System.Drawing.Point(409, 200);
            this.lblMateria.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMateria.Name = "lblMateria";
            this.lblMateria.Size = new System.Drawing.Size(42, 13);
            this.lblMateria.TabIndex = 36;
            this.lblMateria.Text = "Materia";
            // 
            // lblUbic
            // 
            this.lblUbic.AutoSize = true;
            this.lblUbic.Location = new System.Drawing.Point(11, 202);
            this.lblUbic.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUbic.Name = "lblUbic";
            this.lblUbic.Size = new System.Drawing.Size(55, 13);
            this.lblUbic.TabIndex = 35;
            this.lblUbic.Text = "Ubicacion";
            // 
            // lblCorriente
            // 
            this.lblCorriente.AutoSize = true;
            this.lblCorriente.Location = new System.Drawing.Point(217, 205);
            this.lblCorriente.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCorriente.Name = "lblCorriente";
            this.lblCorriente.Size = new System.Drawing.Size(49, 13);
            this.lblCorriente.TabIndex = 34;
            this.lblCorriente.Text = "Corriente";
            // 
            // lblEditorial
            // 
            this.lblEditorial.AutoSize = true;
            this.lblEditorial.Location = new System.Drawing.Point(409, 156);
            this.lblEditorial.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEditorial.Name = "lblEditorial";
            this.lblEditorial.Size = new System.Drawing.Size(44, 13);
            this.lblEditorial.TabIndex = 33;
            this.lblEditorial.Text = "Editorial";
            // 
            // lblAutor
            // 
            this.lblAutor.AutoSize = true;
            this.lblAutor.Location = new System.Drawing.Point(217, 156);
            this.lblAutor.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAutor.Name = "lblAutor";
            this.lblAutor.Size = new System.Drawing.Size(32, 13);
            this.lblAutor.TabIndex = 32;
            this.lblAutor.Text = "Autor";
            // 
            // lblDispo
            // 
            this.lblDispo.AutoSize = true;
            this.lblDispo.Location = new System.Drawing.Point(9, 153);
            this.lblDispo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDispo.Name = "lblDispo";
            this.lblDispo.Size = new System.Drawing.Size(72, 13);
            this.lblDispo.TabIndex = 31;
            this.lblDispo.Text = "Disponibilidad";
            // 
            // lblEdicion
            // 
            this.lblEdicion.AutoSize = true;
            this.lblEdicion.Location = new System.Drawing.Point(409, 98);
            this.lblEdicion.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEdicion.Name = "lblEdicion";
            this.lblEdicion.Size = new System.Drawing.Size(42, 13);
            this.lblEdicion.TabIndex = 30;
            this.lblEdicion.Text = "Edicion";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Location = new System.Drawing.Point(217, 38);
            this.lblTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(33, 13);
            this.lblTitulo.TabIndex = 29;
            this.lblTitulo.Text = "Titulo";
            // 
            // lblNPag
            // 
            this.lblNPag.AutoSize = true;
            this.lblNPag.Location = new System.Drawing.Point(409, 34);
            this.lblNPag.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNPag.Name = "lblNPag";
            this.lblNPag.Size = new System.Drawing.Size(67, 13);
            this.lblNPag.TabIndex = 28;
            this.lblNPag.Text = "No. paginas \r\n";
            // 
            // lblVolumen
            // 
            this.lblVolumen.AutoSize = true;
            this.lblVolumen.Location = new System.Drawing.Point(11, 93);
            this.lblVolumen.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblVolumen.Name = "lblVolumen";
            this.lblVolumen.Size = new System.Drawing.Size(48, 13);
            this.lblVolumen.TabIndex = 27;
            this.lblVolumen.Text = "Volumen\r\n";
            // 
            // lblFecha
            // 
            this.lblFecha.AutoSize = true;
            this.lblFecha.Location = new System.Drawing.Point(217, 98);
            this.lblFecha.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(37, 13);
            this.lblFecha.TabIndex = 26;
            this.lblFecha.Text = "Fecha";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(11, 35);
            this.lblNombre.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(44, 13);
            this.lblNombre.TabIndex = 25;
            this.lblNombre.Text = "Nombre";
            // 
            // btnSalir
            // 
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.Location = new System.Drawing.Point(478, 257);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(75, 26);
            this.btnSalir.TabIndex = 50;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnIngresar
            // 
            this.btnIngresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIngresar.Location = new System.Drawing.Point(320, 257);
            this.btnIngresar.Name = "btnIngresar";
            this.btnIngresar.Size = new System.Drawing.Size(75, 26);
            this.btnIngresar.TabIndex = 49;
            this.btnIngresar.Text = "Ingresar";
            this.btnIngresar.UseVisualStyleBackColor = true;
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiar.Location = new System.Drawing.Point(401, 257);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(75, 26);
            this.btnLimpiar.TabIndex = 51;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            // 
            // wfIngresarLibros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 295);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnIngresar);
            this.Controls.Add(this.cboMateria);
            this.Controls.Add(this.cboCorriente);
            this.Controls.Add(this.cboUbic);
            this.Controls.Add(this.cboEdit);
            this.Controls.Add(this.cboAutor);
            this.Controls.Add(this.txtDispo);
            this.Controls.Add(this.txtEdicion);
            this.Controls.Add(this.txtFecha);
            this.Controls.Add(this.txtVolumen);
            this.Controls.Add(this.txtNPag);
            this.Controls.Add(this.txtTitulo);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.lblMateria);
            this.Controls.Add(this.lblUbic);
            this.Controls.Add(this.lblCorriente);
            this.Controls.Add(this.lblEditorial);
            this.Controls.Add(this.lblAutor);
            this.Controls.Add(this.lblDispo);
            this.Controls.Add(this.lblEdicion);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lblNPag);
            this.Controls.Add(this.lblVolumen);
            this.Controls.Add(this.lblFecha);
            this.Controls.Add(this.lblNombre);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "wfIngresarLibros";
            this.Text = "Ingreso de Libros";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cboMateria;
        private System.Windows.Forms.ComboBox cboCorriente;
        private System.Windows.Forms.ComboBox cboUbic;
        private System.Windows.Forms.ComboBox cboEdit;
        private System.Windows.Forms.ComboBox cboAutor;
        private System.Windows.Forms.TextBox txtDispo;
        private System.Windows.Forms.TextBox txtEdicion;
        private System.Windows.Forms.TextBox txtFecha;
        private System.Windows.Forms.TextBox txtVolumen;
        private System.Windows.Forms.TextBox txtNPag;
        private System.Windows.Forms.TextBox txtTitulo;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label lblMateria;
        private System.Windows.Forms.Label lblUbic;
        private System.Windows.Forms.Label lblCorriente;
        private System.Windows.Forms.Label lblEditorial;
        private System.Windows.Forms.Label lblAutor;
        private System.Windows.Forms.Label lblDispo;
        private System.Windows.Forms.Label lblEdicion;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblNPag;
        private System.Windows.Forms.Label lblVolumen;
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnIngresar;
        private System.Windows.Forms.Button btnLimpiar;
    }
}