﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Prototipo
{
   


    public partial class wfAutor : Form
    { 


        
        public wfAutor()
        {
            InitializeComponent();
        }

        private void wfAutor_Load(object sender, EventArgs e)
        {

        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            int dos;
            string a; 
          
            
            Libros.conexion.ObtenerConexion();
            MessageBox.Show("Conectado");
            a = "";
           
            MySqlCommand comando = new MySqlCommand( string.Format("Insert into tab_autor values ('{0}','{1}','{2}')", a, txtNomAutor.Text , txtApeAutor.Text), Libros.conexion.ObtenerConexion());

           dos =  comando.ExecuteNonQuery();

            

            
        



            
        }
    }
}
