﻿namespace Prototipo
{
    partial class wfAutor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(wfAutor));
            this.btnIngresar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNomAutor = new System.Windows.Forms.TextBox();
            this.lblIngresoAutor = new System.Windows.Forms.Label();
            this.txtApeAutor = new System.Windows.Forms.TextBox();
            this.lblApellidoAutor = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnIngresar
            // 
            this.btnIngresar.Image = ((System.Drawing.Image)(resources.GetObject("btnIngresar.Image")));
            this.btnIngresar.Location = new System.Drawing.Point(314, 234);
            this.btnIngresar.Name = "btnIngresar";
            this.btnIngresar.Size = new System.Drawing.Size(79, 36);
            this.btnIngresar.TabIndex = 0;
            this.btnIngresar.UseVisualStyleBackColor = true;
            this.btnIngresar.Click += new System.EventHandler(this.btnIngresar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(153, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nombre";
            // 
            // txtNomAutor
            // 
            this.txtNomAutor.Location = new System.Drawing.Point(293, 106);
            this.txtNomAutor.Name = "txtNomAutor";
            this.txtNomAutor.Size = new System.Drawing.Size(100, 20);
            this.txtNomAutor.TabIndex = 2;
            // 
            // lblIngresoAutor
            // 
            this.lblIngresoAutor.AutoSize = true;
            this.lblIngresoAutor.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIngresoAutor.Location = new System.Drawing.Point(151, 19);
            this.lblIngresoAutor.Name = "lblIngresoAutor";
            this.lblIngresoAutor.Size = new System.Drawing.Size(199, 25);
            this.lblIngresoAutor.TabIndex = 3;
            this.lblIngresoAutor.Text = "INGRESO AUTOR";
            // 
            // txtApeAutor
            // 
            this.txtApeAutor.Location = new System.Drawing.Point(293, 137);
            this.txtApeAutor.Name = "txtApeAutor";
            this.txtApeAutor.Size = new System.Drawing.Size(100, 20);
            this.txtApeAutor.TabIndex = 4;
            // 
            // lblApellidoAutor
            // 
            this.lblApellidoAutor.AutoSize = true;
            this.lblApellidoAutor.Location = new System.Drawing.Point(153, 153);
            this.lblApellidoAutor.Name = "lblApellidoAutor";
            this.lblApellidoAutor.Size = new System.Drawing.Size(44, 13);
            this.lblApellidoAutor.TabIndex = 5;
            this.lblApellidoAutor.Text = "Apellido";
            // 
            // wfAutor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(493, 320);
            this.Controls.Add(this.lblApellidoAutor);
            this.Controls.Add(this.txtApeAutor);
            this.Controls.Add(this.lblIngresoAutor);
            this.Controls.Add(this.txtNomAutor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnIngresar);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "wfAutor";
            this.Text = "Ingreso Autor";
            this.Load += new System.EventHandler(this.wfAutor_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIngresar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNomAutor;
        private System.Windows.Forms.Label lblIngresoAutor;
        private System.Windows.Forms.TextBox txtApeAutor;
        private System.Windows.Forms.Label lblApellidoAutor;
    }
}