﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Prototipo
{
    public partial class wfEditorial : Form
    {
        public wfEditorial()
        {
            InitializeComponent();
        }

        private void wfEditorial_Load(object sender, EventArgs e)
        {

        }
    }
}
