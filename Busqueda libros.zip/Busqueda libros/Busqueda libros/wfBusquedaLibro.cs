﻿/*Autor: "Biverlyn López"
 * Fecha: "30/Julio/2014"
 * Comentario: "Este módulo mostrará la busqueda de libros, ya sea por autor, titulo, etc." 
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Busqueda_libros
{
    public partial class BusquedaLibros : Form
    {
        public BusquedaLibros()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
